using  JuMP, HiGHS
 
function solve_revin_with_commission()
    # Données
    nbmois = 5
    ca = 200
    cs = 6
    cc = 8000   # commission fixe dès qu'on achète
    nbmax = 500
    sinit = 200
    d = [400, 800, 400, 200, 300]

    model = Model(HiGHS.Optimizer)
    # set_silent(model)  # si besoin

    # Variables
    @variable(model, x[1:nbmois] >= 0, Int)   # achat
    @variable(model, s[1:nbmois] >= 0, Int)   # stock
    @variable(model, t[1:nbmois], Bin)        # binaire (1 si achat > 0)

    # Contraintes

    # Équilibre stock/demande
    @constraint(model, x[1] + sinit == d[1] + s[1])
    @constraint(model, [i in 2:nbmois], x[i] + s[i-1] == d[i] + s[i])

    # Limite d'achat
    @constraint(model, [i in 1:nbmois], x[i] <= nbmax)

    # x[i] = 0 si t[i] = 0 (achat impossible sans commission)
    # => x[i] <= nbmax * t[i]
    @constraint(model, [i in 1:nbmois], x[i] <= nbmax * t[i])

    # Objectif : min Σ (ca*x[i] + cs*s[i] + cc*t[i])
    @objective(
        model,
        Min,
        sum(ca*x[i] + cs*s[i] + cc*t[i] for i in 1:nbmois)
    )

    # Résolution
    optimize!(model)

    # Analyse
    status = termination_status(model)
    if status == MOI.OPTIMAL
        println("=== Problème Revin (avec commission) : OPTIMAL ===")
        xsol = [value(x[i]) for i in 1:nbmois]
        ssol = [value(s[i]) for i in 1:nbmois]
        tsol = [value(t[i]) for i in 1:nbmois]
        obj  = objective_value(model)

        println("x = ", xsol, " (achat par mois)")
        println("s = ", ssol, " (stock en fin de mois)")
        println("t = ", tsol, " (binaire, indique si on achète)")
        println("Coût total = ", obj)
    else
        println("Statut : ", status)
    end
end
