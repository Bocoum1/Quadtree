using JuMP, HiGHS

function model_distanciel(solverSelected::DataType, c::Vector{Int64}, A::Vector{Vector{Tuple{Int64,Int64}}},b::Vector{Int64},nbvar::Int64)
    #Creation du model
    m =Model(solverSelected)
    set_silent(m)
#Les variables
@variable(m,x[1:nbvar],binary=true)

#La fonction objective
@objective(m,Max,sum(c[j]x[j] for j in 1:nbvar))

#LesContraintes
@constraint(m,X[i=1:length(A)],sum(v*x[j] for (j,v) in A[i])<=b[i])
 return m
end

function distancielexo2()
#Les données
c=[1,3,7,3,12,4,9,4,3]
A::Vector{Vector{Tuple{Int64,Int64}}} = Vector{Vector{Tuple{Int64,Int64}}}(undef,11)
A[1] = [(1,1),(5,1)]
A[2] = [(2,1),(5,1)]
A[3] = [(3,1),(5,1)]
A[4] = [(3,1),(4,1)]
A[5] = [(2,1),(7,1)]
A[6] = [(5,1),(7,1)]
A[7] = [(5,1),(4,1)]
A[8] = [(6,1),(7,1)]
A[9] = [(6,1),(8,1)]
A[10] = [(8,1),(4,1)]
A[11] = [(5,1),(9,1)]

nbvar=9
b=fill(1,11)
#Creation du model à partir des données
m::Model=model_distanciel(HiGHS.Optimizer,c,A,b,nbvar)

#Resolution
optimize!(m)
status= termination_status(m)
if status == MOI.OPTIMAL
    println("Problème résolu à l'optimalité")

    println("z = ",objective_value(m)) # affichage de la valeur optimale
    x=value.(m[:x])
    println("x = ",x) # affichage des valeurs du vecteur de variables issues du modèle
for j in 1:nbvar
    if x[j]>0
        println("x$j =1 ; coeef objectif=  ",c[j])
    end
end
else
    println("Statut :", status)
end
end